//background.js

console.log("SLS background loaded");
const DEFAULT_SETTINGS = {
  enabled: true,
  forceHeader: true,
  uiLanguage: "en",
  region: "ch",
  resultLanguage: "lang_en",
  acceptLanguage: "en-US,en;q=0.9"
};

const getSettings = async () => {
  const stored = await browser.storage.local.get(DEFAULT_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...stored };
};

const isGoogleHost = (hostname) => {
  return hostname === "google.com" || hostname === "www.google.com" || hostname.startsWith("google.") || hostname.startsWith("www.google.");
};

const setParam = (url, key, value) => {
  if (value) url.searchParams.set(key, value);
};

const buildRedirectUrl = (rawUrl, settings) => {
  const url = new URL(rawUrl);

  if (!isGoogleHost(url.hostname)) return null;

  setParam(url, "hl", settings.uiLanguage);

  const isSearchPage = url.pathname === "/search" || url.searchParams.has("q");

  if (isSearchPage) {
    setParam(url, "gl", settings.region);
    setParam(url, "lr", settings.resultLanguage);
  }

  const nextUrl = url.toString();

  return nextUrl === rawUrl ? null : nextUrl;
};

browser.webRequest.onBeforeRequest.addListener(
  async (details) => {
    console.log("Request seen:", details.url, details.type, details.incognito);
    if (details.type !== "main_frame") return {};

    const settings = await getSettings();
    if (!settings.enabled) return {};

    const redirectUrl = buildRedirectUrl(details.url, settings);
    if (!redirectUrl) return {};

    return { redirectUrl };
  },
  {
    urls: [
      "*://www.google.*/*",
      "*://google.*/*"
    ]

  },
  ["blocking"]
);

browser.webRequest.onBeforeSendHeaders.addListener(
  async (details) => {
    if (details.type !== "main_frame") return {};

    const settings = await getSettings();
    if (!settings.enabled || !settings.forceHeader) return {};

    const requestHeaders = details.requestHeaders || [];

    const existingHeader = requestHeaders.find(
      (header) => header.name.toLowerCase() === "accept-language"
    );

    if (existingHeader) {
      existingHeader.value = settings.acceptLanguage;
    } else {
      requestHeaders.push({
        name: "Accept-Language",
        value: settings.acceptLanguage
      });
    }

    return { requestHeaders };
  },
  {
    urls: [
      "*://www.google.*/*",
      "*://google.*/*"
    ]

  },
  ["blocking", "requestHeaders"]
);